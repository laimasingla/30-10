package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class AccountDaoImpl implements AccountDao {
	private EntityManager entityManager;

	public AccountDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}

	@Override
	public BigInteger getUci(BigInteger accountNumber) throws IBSException {

		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select c.UCI from AccountBean d JOIN d.customerBeanObject c where d.accountNumber=?1",
				BigInteger.class);
		query.setParameter(1, accountNumber);

		return query.getSingleResult();

	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		boolean result = false;

		AccountBean d = entityManager.find(AccountBean.class, accountNumber);

		if (d != null)
			result = true;

		return result;
	}

}
