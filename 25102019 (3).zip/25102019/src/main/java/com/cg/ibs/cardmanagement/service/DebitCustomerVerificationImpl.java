package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.dao.DebitCardDao;
import com.cg.ibs.cardmanagement.dao.DebitCardDaoImpl;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDao;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDaoImpl;
import com.cg.ibs.cardmanagement.dao.AccountDao;
import com.cg.ibs.cardmanagement.dao.AccountDaoImpl;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDaoImpl;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCustomerVerificationImpl implements DebitCustomerVerification {

	CustomerDao customerDao = new CustomerDaoImpl();
	CaseIdDao caseIdDao = new CaseIdDaoImpl();
	DebitCardTransactionDao debitCardTransactionDao = new DebitCardTransactionDaoImpl();

	DebitCardDao debitCardDao = new DebitCardDaoImpl();

	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException {
		boolean check;
		String debitCardNum = debitCardNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(debitCardNum);
		if (!(matcher.find() && matcher.group().equals(debitCardNum)))
			throw new IBSException(ErrorMessages.INC_LENGTH_CARD_MESSAGE);
		
		
			check = debitCardDao.verifyDebitCardNumber(debitCardNumber);
			
		
		
		if (!check)
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		return (check);
	}
	
	

	@Override
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException {
		try {
			if (pin.equals(debitCardDao.getDebitCardPin(debitCardNumber))) {

				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		boolean check;
		String accountNum = accountNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{11}");
		Matcher matcher = pattern.matcher(accountNum);
		if (!(matcher.find() && matcher.group().equals(accountNum)))
			throw new IBSException(ErrorMessages.INC_LENGTH_ACCOUNT_MESSAGE);
		try {
			check = accountDao.verifyAccountNumber(accountNumber);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
		if (!check)
			throw new IBSException(ErrorMessages.INVALID_ACCOUNT_MESSAGE);
		return (check);
	}

	@Override
	public boolean checkDebitTransactionId(BigInteger transactionId) throws IBSException {
		boolean transactionResult = debitCardTransactionDao.verifyDebitTransactionId(transactionId);
		if (!transactionResult)
			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);

		return transactionResult;
	}

	@Override
	public boolean getDebitCardStatus(BigInteger debitCardNumber) throws IBSException {
		boolean status = false;
		try {
			String existingStatus = debitCardDao.getDebitCardStatus(debitCardNumber);

			if (!existingStatus.contains("Blocked")) {
				status = true;
			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
		return status;
	}

}
