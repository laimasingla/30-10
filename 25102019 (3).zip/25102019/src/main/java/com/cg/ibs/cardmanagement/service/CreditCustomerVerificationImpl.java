package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ibs.cardmanagement.dao.CustomerDaoImpl;
import com.cg.ibs.cardmanagement.bean.CreditCardStatus;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDaoImpl;
import com.cg.ibs.cardmanagement.dao.CreditCardDao;
import com.cg.ibs.cardmanagement.dao.CreditCardDaoImpl;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDao;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDaoImpl;
import com.cg.ibs.cardmanagement.dao.CustomerDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCustomerVerificationImpl implements CreditCustomerVerification {

	CaseIdDao caseIdDao = new CaseIdDaoImpl();

	CreditCardTransactionDao creditCardTransactionDao = new CreditCardTransactionDaoImpl();
	
	CreditCardDao creditCardDao = new CreditCardDaoImpl();

	CustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		String creditCardNum = creditCardNumber.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(creditCardNum);
		if (!(matcher.find() && matcher.group().equals(creditCardNum)))
			throw new IBSException(ErrorMessages.INC_LENGTH_CARD_MESSAGE);
		boolean check1 = creditCardDao.verifyCreditCardNumber(creditCardNumber);
		if (!check1)
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);

		return (check1);	
	}

	@Override
	public boolean verifyCreditPin(String pin, BigInteger creditCardNumber) throws IBSException {
		try {
			if (pin.equals(creditCardDao.getCreditCardPin(creditCardNumber))) {

				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}
	}

	@Override
	public String verifyCreditcardType(BigInteger creditCardNumber) throws IBSException {
		
		
	
			String type;
			try {
				type = creditCardDao.getcreditCardType(creditCardNumber);
			} catch (IBSException e) {
				throw new IBSException(ErrorMessages.l);
			}
			return type;
		
	}

	@Override
	public boolean verifyCreditCardTransactionId(BigInteger transactionId) throws IBSException {
		boolean transactionResult = creditCardTransactionDao.verifyCreditTransactionId(transactionId);
		if (!transactionResult)
			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);

		return transactionResult;
	}

	@Override
	public boolean getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		boolean status = false;
		try {
			CreditCardStatus existingStatus = creditCardDao.getCreditCardStatus(creditCardNumber);
			if (!existingStatus.equals(CreditCardStatus.APPROVED)) {
				status = true;
			}
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.l);
		}

		return status;
	}

}
