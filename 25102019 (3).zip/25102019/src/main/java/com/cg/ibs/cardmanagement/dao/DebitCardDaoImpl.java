package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCardDaoImpl implements DebitCardDao {

	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public DebitCardDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = JpaUtilImpl.getTransaction();
	}

	@Override
	public BigInteger getAccountNumber(BigInteger debitCardNumber) throws IBSException {
              
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select a.accountNumber from DebitCardBean d INNER JOIN d.accountBeanObject a where d.cardNumber=?1",
				BigInteger.class);
		query.setParameter(1, debitCardNumber);

		return query.getSingleResult();

	}

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {

		TypedQuery<DebitCardBean> debitQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_DEBIT_CARD,
				DebitCardBean.class);
		List<DebitCardBean> debitCards = debitQuery.getResultList();

		return debitCards;

	}

	@Override
	public void actionANDC(DebitCardBean bean) throws IBSException {
		entityTransaction.begin();
		entityManager.persist(bean);
		entityTransaction.commit();
	}

	@Override
	public String getdebitCardType(BigInteger debitCardNumber) throws IBSException {
		TypedQuery<String> query = entityManager
				.createQuery("select d.cardType from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
		query.setParameter("debitCardNum", debitCardNumber);
		return query.getSingleResult();

	}

	@Override
	public boolean verifyDebitCardNumber(BigInteger debitCardNum) throws IBSException {
		boolean result = false;
		DebitCardBean d = entityManager.find(DebitCardBean.class, debitCardNum);
		if (d != null)
			result = true;
		return result;

	}

	@Override
	public String getDebitCardStatus(BigInteger debitCardNumber) throws IBSException {

		TypedQuery<String> query = entityManager.createQuery("select d.cardStatus from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
		query.setParameter("debitCardNum", debitCardNumber);
		
		return query.getSingleResult();
	}

	@Override
	public BigInteger getDMAccountNumber(BigInteger debitCardNumber) throws IBSException {

		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select a.accountNumber from DebitCardBean d join d.accountBeanObject  a where d.cardNumber=:debitCardNum",
				BigInteger.class);
		query.setParameter("debitCardNum", debitCardNumber);

		return query.getSingleResult();

	}

	@Override
	public void actionUpgradeDC(String queryId) throws IBSException {
		TypedQuery<CaseIdBean> query = entityManager
				.createQuery("select d from CaseIdBean d where d.caseIdTotal =:queryid", CaseIdBean.class);
		query.setParameter("queryid", queryId);
		CaseIdBean caseIdBean = query.getSingleResult();
		BigInteger cardNum = caseIdBean.getCardNumber();
		String type = caseIdBean.getDefineServiceRequest();
		DebitCardBean cardBean = entityManager.find(DebitCardBean.class, cardNum);
		cardBean.setCardType(type);
	}

	@Override
	public String getDebitCardPin(BigInteger debitCardNumber) throws IBSException {
		TypedQuery<String> query = entityManager
				.createQuery("select d.currentPin from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
		query.setParameter("debitCardNum", debitCardNumber);

		return query.getSingleResult();
	}

	@Override
	public void setNewDebitPin(BigInteger debitCardNumber, String newPin) throws IBSException {
		DebitCardBean cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);
	    entityTransaction.begin();
		cardBean.setCurrentPin(newPin);
		entityTransaction.commit();
	   
	}

	@Override
	public void actionBlockDC(String queryId, String status) throws IBSException {

		TypedQuery<BigInteger> query = entityManager
				.createQuery("select d.cardNumber from CaseIdBean d where d.caseIdTotal =:queryid", BigInteger.class);
		query.setParameter("queryid", queryId);
		BigInteger cardnum = query.getSingleResult();
		DebitCardBean cardBean = entityManager.find(DebitCardBean.class, cardnum);
		System.out.println(cardnum);
		
		  entityTransaction.begin();
		cardBean.setCardStatus(status);
		entityTransaction.commit();
	}
}
